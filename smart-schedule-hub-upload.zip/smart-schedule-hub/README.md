# 🧠 Smart Schedule Hub

A smart, AI-powered work and team task scheduler. Built with React, TypeScript, and Tailwind CSS.

## ✨ Features

### Employee View
- **Add & manage tasks** — name, description, priority (high/medium/low), effort level, duration, preferred time of day
- **Auto-scheduling** — tasks are automatically placed on your weekly calendar based on priority and effort
- **Smart Mode** (Week 2+) — learns your productivity patterns and schedules tasks during your peak hours
- **Fixed tasks** — lock a task to a specific time slot (e.g. standup at 9AM, never rescheduled)
- **Drag-and-drop rescheduling** — manually reposition tasks on the weekly grid
- **Task reminders** — get notified 15 minutes before and at task time
- **Simulate next week** — preview your next week's auto-generated schedule before committing
- **Dashboard** — energy curve, cognitive load meter, weekly completion chart, priority distribution

### Manager View
- **Team overview** — see every employee's tasks, schedule, completion rate, and peak working hours
- **Assign tasks to individuals** — push tasks directly into an employee's schedule
- **Broadcast to all** — send meetings or announcements to every employee at once

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- npm

### Installation

```bash
git clone https://github.com/BhagatShubhangi/smart-schedule-hub.git
cd smart-schedule-hub
npm install
npm run dev
```

The app runs at `http://localhost:5173`

### Default Login

| Role     | Username  | Password    |
|----------|-----------|-------------|
| Manager  | manager   | manager123  |
| Employee | Sign up → | Your choice |

## 🏗️ Tech Stack

| Layer    | Tech                                |
|----------|-------------------------------------|
| Frontend | React 18, TypeScript, Vite          |
| Styling  | Tailwind CSS, shadcn/ui             |
| Charts   | Recharts                            |
| Routing  | React Router v6                     |
| State    | localStorage (per-user, persistent) |
| Icons    | Lucide React                        |

## 📁 Project Structure

```
src/
├── components/
│   ├── ui/                # shadcn/ui component library
│   ├── Navbar.tsx         # Employee navigation
│   └── ManagerNavbar.tsx  # Manager navigation
├── pages/
│   ├── Login.tsx          # Auth (sign in / sign up)
│   ├── AddTasks.tsx       # Task creation & management
│   ├── WeeklySchedule.tsx # Drag-and-drop weekly calendar
│   ├── Dashboard.tsx      # Analytics & insights
│   └── ManagerDashboard.tsx # Manager team view
└── lib/
    ├── auth.ts            # User auth (localStorage)
    ├── taskStore.ts       # Task CRUD + smart scheduler
    └── types.ts           # Shared TypeScript types
```

## 🧠 Smart Scheduling Algorithm

1. **Fixed tasks** are placed first at their locked hour
2. Remaining tasks sorted by **priority** (high → low) then **effort** (intense → light)
3. **Week 1**: Placed in preferred time windows (morning / afternoon / evening)
4. **Week 2+ Smart Mode**: Uses completion pattern data to find your most productive time slots per priority level

## 🛠️ Scripts

| Command           | Description                       |
|-------------------|-----------------------------------|
| `npm run dev`     | Start dev server (port 5173)      |
| `npm run build`   | Production build → `dist/`        |
| `npm run preview` | Preview production build          |
| `npm run lint`    | Run ESLint                        |
| `npm run test`    | Run unit tests (Vitest)           |

## 🚢 Deployment

Builds to a static `dist/` folder — deploy anywhere:

- **Vercel**: Connect GitHub repo → auto-deploys on push
- **Netlify**: Drag `dist/` or connect GitHub
- **GitHub Pages**: Use `gh-pages` to publish `dist/`

---

Made with ❤️ by Shubhangi Bhagat
